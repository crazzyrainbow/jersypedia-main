<footer>
    <div class="container">
        <div class="row">
            <div class="col text-center">
                <p>{{ date('Y') }} © Jerseypedia</p>
            </div>
        </div>
    </div>
</footer>